from AppOpener import open
import sys
open(sys.argv[1])