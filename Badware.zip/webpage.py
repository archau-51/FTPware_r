import webbrowser
import sys
webbrowser.open(sys.argv[1], new=0, autoraise=True)