from playsound import playsound
import os
username = os.getlogin
playsound(fr'C:\users\{username}\AppData\local\Aryan\Badware\sentaud.wav')
#os.remove("sentaud.mp3")